<?php
header("Access-Control-Allow-Origin: *");
use vendor\script\Api\Api;
