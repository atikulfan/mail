<?php 
use vendor\script\Route;
use function vendor\script\view;
Route::get('/', function () {
    return view("wellcome");
});
