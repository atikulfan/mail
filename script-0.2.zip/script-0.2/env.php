<?php
namespace env;
class env{
    /*
        ||------------------------------------------||
        || DATABASE CONECTIO INFORMATION EDETE IT   ||
        ||------------------------------------------||
            */
           public static function DBINFO(){
                return [
                    'HOST_NAME'=>'localhost',
                    'USER_NAME'=>'root',
                    'PASSWORD'=>'',
                    'DB_NAMES'=>'curd' //databse names
                ];
           }
            /*
        ||------------------------------------------||
        || DATABASE CONECTIO INFORMATION END        ||
        ||------------------------------------------||
        */


        
        /*
        ||------------------------------------------||
        || APP CONECTIO INFORMATION EDETE IT        ||
        ||------------------------------------------||
            */
            public static function APP_INFO(){
                return [
                    'App_names'=>'Curd Project',
                    'Http'=>isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',
                    'Url'=>$_SERVER['HTTP_HOST'],
                    'notfoud'=>"<span class='notfound'>404</span>"
                ];
           }
            /*
        ||------------------------------------------||
        || APP CONECTION INFORMATION END            ||
        ||------------------------------------------||
        */


         /*
        ||------------------------------------------||
        || MAIL CONECTION INFORMATION EDETE IT      ||
        ||------------------------------------------||
            */
            static function MAIL_CON(){
                return[
                    'HOST'=>'smtp.',
                    'USER_NAMES'=>'',
                    'PASSWORD'=>''
                ];
            }
            /*
        ||------------------------------------------||
        || MAIL CONECTION INFORMATION END             ||
        ||------------------------------------------||
        */

        
        
}
