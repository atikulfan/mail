const Event = {};
Event.selector = (slector) => document.querySelector(slector);
Event.click = (slector, calback) => {
    const element = Event.selector(slector);
    if (element != null) {
        element.addEventListener("click", (e) => {
            calback(e);
        })
    }
}
Event.load = (calback) => {
    addEventListener("DOMContentLoaded", (e) => {
        calback(e);
    })
}
Event.submit = (slector, calback) => {
    const element = Event.selector(slector);
    if (element != null) {
        element.addEventListener("submit", (e) => {
            calback(e);
        })
    }
}
export default Event;