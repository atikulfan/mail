function Imgload(input, showInput) {
  input.change(function (e) {
    if (this.files && this.files[0]) {
      var reader = new FileReader();
      reader.onload = function (event) {
        showInput.attr('src', event.target.result);
      }
      reader.readAsDataURL(this.files[0]);
    }
  })

}
export default Imgload;