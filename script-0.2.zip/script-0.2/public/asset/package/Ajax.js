export const Ajax = {};

Ajax.config = {
    name: 'ajax',
    about: "onlye user for php scritp fremwork create this developer"
}
//get method define
Ajax.get = (url, body = null, calback,submit=true,header=null) => {
    const data   = typeof (body) == "object" ? body : {};
    const headers = typeof (header) == "object" ? header : {};
    if(submit){
        $.ajax({
            method: "GET",
            url:url,
            data: data,
            headers,
            success: function (data) {calback(data)}
        });
    }else{
        $.ajax({
            method: "GET",
            url:url,
            contentType:submit,
            processData:submit,
            data: data,
            headers,
            success: function (data) {calback(data)}
        });
    }
}
//post method define
Ajax.post = (url, body = null, calback,submit=true,header=null) => {
    const data   = typeof (body) == "object" ? body : {};
    const headers = typeof (header) == "object" ? header : {};
    if(submit){
        $.ajax({
            method: "POST",
            url:url,
            data: data,
            headers,
            success: function (data) {calback(data)}
        });
    }else{
        $.ajax({
            method: "POST",
            url:url,
            contentType:submit,
            processData:submit,
            data: data,
            headers,
            success: function (data) {calback(data)}
        });
    }
}

