function Style(size,color) {
    return `
    .loading-contaienr{
        position: absolute;
        z-index: 60;
        height: 100%;
        width: 100%;
        background: #0000005c;
        display: flex;
        justify-content: center;
        align-items: center;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
    }
    @keyframes loading {
        0%{
            rotate: 0deg;
        }
        100%{
            rotate: 360deg;
        }
    }
    .loading-box{
        height: ${size}px;
        width: ${size}px;
        border-radius: 50%;
        border: 5px solid ${color};
        border-right-color: #0000;
        animation-name: loading;
        animation-duration: 1s;
        animation-iteration-count: infinite;
      }
    `
}
function loading(color="blue",size=50) {
  const styleConta = document.createElement("style");
        styleConta.setAttribute("id","loadingStyle");
        styleConta.innerHTML=Style(size,color)
  const contaienr = document.createElement("div");
        contaienr.classList.add("loading-contaienr");
        contaienr.setAttribute("id",'loadingContainer');
        contaienr.append(styleConta)
  const loadinBox = document.createElement("div");
       loadinBox.classList.add("loading-box")
       loadinBox.setAttribute("id","loadingBox")
       contaienr.append((loadinBox))
       return {
          show:()=>{document.body.append(contaienr)},
          hide:()=>{contaienr.remove()}
       }
}

export default loading;