export function thimset(links) {
    localStorage.setItem("thim",JSON.stringify({url:links}));
    thimload();
}
export function thimload(){
  const {url}=  localStorage.getItem("thim")==null || localStorage.getItem("thim")==""?"":JSON.parse(localStorage.getItem("thim"));
  document.querySelector("#thim").setAttribute("href",url);
}
