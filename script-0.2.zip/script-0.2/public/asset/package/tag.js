export const getTag = (name) => { return document.querySelector(name) };
export const log = (log) => console.log(log);
export const url = (path = null) => {
    let baseurl = location.origin;
    baseurl = baseurl.replace("/", "");
    if (path == null || path == "") {
        baseurl += "/";
    } else {
        baseurl += "/" + path;
    }
    return baseurl;
}
export const get = (name) => {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    if (name == "" || name == null) {
        return urlParams;
    } else {
        return urlParams.get(name) == null ? "" : urlParams.get(name);
    }
}
export const tag = (name) => {
    const eliment = document.createElement(name);
    return {
        tag: function () {
            return eliment;
        },
        add: function (tag = null, mode = "a") {
            if (tag == null || tag == "") {
                if (mode == "a") {
                    document.body.append(eliment);
                } else {
                    document.body.prepend(eliment);
                }
            } else {
                if (mode == "p") {
                    tag.prepend(eliment);
                } else {
                    tag.append(eliment);
                }
            }
            return true;
        },
        text: function (text) {
            text == "" ? false : eliment.innerText = text; return true;
        },
        addClass: function (name) {
            eliment.classList.add(name);
            return true;
        },
        removeClass: function (name) {
            eliment.classList.remove(name);
            return true;
        },
        addAttr: function (name, value) {
            return eliment.setAttribute(name, value);
        },
        getAttr: function (name) {
            return eliment.getAttribute(name);
        },
        removeAttr: function (name) {
            return eliment.removeAttribute(name);
        },
        addCss: function (value) {
            this.addAttr("style", value);
        },
        style: eliment.style,
        hide: function () {
            eliment.style.display = "none";
        },
        show: function () {
            eliment.style.display = "block";
        },
        html: function (code) {
            eliment.innerHTML = code;
        },
        append: function (tag, mode = "a") {
            if (mode == "a") {
                eliment.append(tag);
            } else {
                eliment.prepend(tag);
            }
        },
        remove: function () {
            eliment.remove();
        },
        on: function (event, success) {
            eliment.addEventListener(event, success);
        },
        click: function (success) {
            this.on("click", success);
        },
        getText: function () {
            return eliment.innerText;
        },
        getHtml: function () {
            return eliment.innerHTML;
        },
        addId: function (name) {
            return eliment.setAttribute("id", name);
        },
        getId: function () {
            return eliment.getAttribute();
        },
        getValue: function () {
            return eliment.value;
        },
        AddValue: function (value) {
            return eliment.value = value;
        },
        addType: function (type) {
            return eliment.setAttribute("type", type);

        },
        getType: function () {
            return eliment.getAttribute();
        },
        class: function (name) {
            return eliment.setAttribute("class", name);
        }
    }
}
export const addTitle = (title) => {
    return document.title = title;
}
export const getTitle = () => {
    return document.title;
}
export const Stylesheet = (name) => {
    const link = tag("link");
    link.addAttr("rel", "stylesheet");
    link.addAttr("href", ("src/css/" + name));
    link.add(document.head);
}
export const Scriptjs = (name) => {
    const link = tag("script");
    link.addType("module");
    link.addAttr("src", ("src/js/" + name));
    link.add(document.body);
}
export const $_GET = (name) => {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    if (name == "" || name == null) {
        return urlParams;
    } else {
        return urlParams.get(name) == null ? "" : urlParams.get(name);
    }
}
export function a(elm = null) {
    let el = tag('a')
    elm == null ? '' : el.add(elm);
    return el;
}


export function abbr(elm = null) {
    let el = tag('abbr')
    elm == null ? '' : el.add(elm);
    return el;
}


export function acronym(elm = null) {
    let el = tag('acronym')
    elm == null ? '' : el.add(elm);
    return el;
}


export function address(elm = null) {
    let el = tag('address')
    elm == null ? '' : el.add(elm);
    return el;
}


export function applet(elm = null) {
    let el = tag('applet')
    elm == null ? '' : el.add(elm);
    return el;
}


export function area(elm = null) {
    let el = tag('area')
    elm == null ? '' : el.add(elm);
    return el;
}


export function article(elm = null) {
    let el = tag('article')
    elm == null ? '' : el.add(elm);
    return el;
}


export function aside(elm = null) {
    let el = tag('aside')
    elm == null ? '' : el.add(elm);
    return el;
}


export function audio(elm = null) {
    let el = tag('audio')
    elm == null ? '' : el.add(elm);
    return el;
}


export function b(elm = null) {
    let el = tag('b')
    elm == null ? '' : el.add(elm);
    return el;
}


export function base(elm = null) {
    let el = tag('base')
    elm == null ? '' : el.add(elm);
    return el;
}


export function basefont(elm = null) {
    let el = tag('basefont')
    elm == null ? '' : el.add(elm);
    return el;
}


export function bdi(elm = null) {
    let el = tag('bdi')
    elm == null ? '' : el.add(elm);
    return el;
}


export function bdo(elm = null) {
    let el = tag('bdo')
    elm == null ? '' : el.add(elm);
    return el;
}


export function big(elm = null) {
    let el = tag('big')
    elm == null ? '' : el.add(elm);
    return el;
}


export function blockquote(elm = null) {
    let el = tag('blockquote')
    elm == null ? '' : el.add(elm);
    return el;
}


export function body(elm = null) {
    let el = tag('body')
    elm == null ? '' : el.add(elm);
    return el;
}


export function br(elm = null) {
    let el = tag('br')
    elm == null ? '' : el.add(elm);
    return el;
}


export function button(elm = null) {
    let el = tag('button')
    elm == null ? '' : el.add(elm);
    return el;
}


export function canvas(elm = null) {
    let el = tag('canvas')
    elm == null ? '' : el.add(elm);
    return el;
}


export function caption(elm = null) {
    let el = tag('caption')
    elm == null ? '' : el.add(elm);
    return el;
}


export function center(elm = null) {
    let el = tag('center')
    elm == null ? '' : el.add(elm);
    return el;
}


export function cite(elm = null) {
    let el = tag('cite')
    elm == null ? '' : el.add(elm);
    return el;
}


export function code(elm = null) {
    let el = tag('code')
    elm == null ? '' : el.add(elm);
    return el;
}


export function col(elm = null) {
    let el = tag('col')
    elm == null ? '' : el.add(elm);
    return el;
}


export function colgroup(elm = null) {
    let el = tag('colgroup')
    elm == null ? '' : el.add(elm);
    return el;
}


export function data(elm = null) {
    let el = tag('data')
    elm == null ? '' : el.add(elm);
    return el;
}


export function datalist(elm = null) {
    let el = tag('datalist')
    elm == null ? '' : el.add(elm);
    return el;
}


export function dd(elm = null) {
    let el = tag('dd')
    elm == null ? '' : el.add(elm);
    return el;
}


export function del(elm = null) {
    let el = tag('del')
    elm == null ? '' : el.add(elm);
    return el;
}


export function dfn(elm = null) {
    let el = tag('dfn')
    elm == null ? '' : el.add(elm);
    return el;
}


export function dialog(elm = null) {
    let el = tag('dialog')
    elm == null ? '' : el.add(elm);
    return el;
}


export function dir(elm = null) {
    let el = tag('dir')
    elm == null ? '' : el.add(elm);
    return el;
}


export function div(elm = null) {
    let el = tag('div')
    elm == null ? '' : el.add(elm);
    return el;
}


export function dl(elm = null) {
    let el = tag('dl')
    elm == null ? '' : el.add(elm);
    return el;
}


export function dt(elm = null) {
    let el = tag('dt')
    elm == null ? '' : el.add(elm);
    return el;
}


export function em(elm = null) {
    let el = tag('em')
    elm == null ? '' : el.add(elm);
    return el;
}


export function embed(elm = null) {
    let el = tag('embed')
    elm == null ? '' : el.add(elm);
    return el;
}


export function fieldset(elm = null) {
    let el = tag('fieldset')
    elm == null ? '' : el.add(elm);
    return el;
}


export function figcaption(elm = null) {
    let el = tag('figcaption')
    elm == null ? '' : el.add(elm);
    return el;
}


export function figure(elm = null) {
    let el = tag('figure')
    elm == null ? '' : el.add(elm);
    return el;
}


export function font(elm = null) {
    let el = tag('font')
    elm == null ? '' : el.add(elm);
    return el;
}


export function footer(elm = null) {
    let el = tag('footer')
    elm == null ? '' : el.add(elm);
    return el;
}


export function form(elm = null) {
    let el = tag('form')
    elm == null ? '' : el.add(elm);
    return el;
}


export function frame(elm = null) {
    let el = tag('frame')
    elm == null ? '' : el.add(elm);
    return el;
}


export function frameset(elm = null) {
    let el = tag('frameset')
    elm == null ? '' : el.add(elm);
    return el;
}


export function head(elm = null) {
    let el = tag('head')
    elm == null ? '' : el.add(elm);
    return el;
}


export function header(elm = null) {
    let el = tag('header')
    elm == null ? '' : el.add(elm);
    return el;
}


export function hgroup(elm = null) {
    let el = tag('hgroup')
    elm == null ? '' : el.add(elm);
    return el;
}


export function h1(elm = null) {
    let el = tag('h1')
    elm == null ? '' : el.add(elm);
    return el;
}


export function h2(elm = null) {
    let el = tag('h2')
    elm == null ? '' : el.add(elm);
    return el;
}


export function h3(elm = null) {
    let el = tag('h3')
    elm == null ? '' : el.add(elm);
    return el;
}


export function h4(elm = null) {
    let el = tag('h4')
    elm == null ? '' : el.add(elm);
    return el;
}


export function h5(elm = null) {
    let el = tag('h5')
    elm == null ? '' : el.add(elm);
    return el;
}


export function h6(elm = null) {
    let el = tag('h6')
    elm == null ? '' : el.add(elm);
    return el;
}


export function hr(elm = null) {
    let el = tag('hr')
    elm == null ? '' : el.add(elm);
    return el;
}


export function html(elm = null) {
    let el = tag('html')
    elm == null ? '' : el.add(elm);
    return el;
}


export function i(elm = null) {
    let el = tag('i')
    elm == null ? '' : el.add(elm);
    return el;
}


export function iframe(elm = null) {
    let el = tag('iframe')
    elm == null ? '' : el.add(elm);
    return el;
}


export function img(elm = null) {
    let el = tag('img')
    elm == null ? '' : el.add(elm);
    return el;
}


export function input(elm = null) {
    let el = tag('input')
    elm == null ? '' : el.add(elm);
    return el;
}


export function ins(elm = null) {
    let el = tag('ins')
    elm == null ? '' : el.add(elm);
    return el;
}


export function kdb(elm = null) {
    let el = tag('kdb')
    elm == null ? '' : el.add(elm);
    return el;
}


export function keygen(elm = null) {
    let el = tag('keygen')
    elm == null ? '' : el.add(elm);
    return el;
}


export function label(elm = null) {
    let el = tag('label')
    elm == null ? '' : el.add(elm);
    return el;
}


export function legend(elm = null) {
    let el = tag('legend')
    elm == null ? '' : el.add(elm);
    return el;
}


export function li(elm = null) {
    let el = tag('li')
    elm == null ? '' : el.add(elm);
    return el;
}


export function link(elm = null) {
    let el = tag('link')
    elm == null ? '' : el.add(elm);
    return el;
}


export function main(elm = null) {
    let el = tag('main')
    elm == null ? '' : el.add(elm);
    return el;
}


export function map(elm = null) {
    let el = tag('map')
    elm == null ? '' : el.add(elm);
    return el;
}


export function mark(elm = null) {
    let el = tag('mark')
    elm == null ? '' : el.add(elm);
    return el;
}


export function menu(elm = null) {
    let el = tag('menu')
    elm == null ? '' : el.add(elm);
    return el;
}


export function menuitem(elm = null) {
    let el = tag('menuitem')
    elm == null ? '' : el.add(elm);
    return el;
}


export function meta(elm = null) {
    let el = tag('meta')
    elm == null ? '' : el.add(elm);
    return el;
}


export function meter(elm = null) {
    let el = tag('meter')
    elm == null ? '' : el.add(elm);
    return el;
}


export function nav(elm = null) {
    let el = tag('nav')
    elm == null ? '' : el.add(elm);
    return el;
}


export function noframes(elm = null) {
    let el = tag('noframes')
    elm == null ? '' : el.add(elm);
    return el;
}


export function noscript(elm = null) {
    let el = tag('noscript')
    elm == null ? '' : el.add(elm);
    return el;
}


export function object(elm = null) {
    let el = tag('object')
    elm == null ? '' : el.add(elm);
    return el;
}


export function ol(elm = null) {
    let el = tag('ol')
    elm == null ? '' : el.add(elm);
    return el;
}


export function optgroup(elm = null) {
    let el = tag('optgroup')
    elm == null ? '' : el.add(elm);
    return el;
}


export function option(elm = null) {
    let el = tag('option')
    elm == null ? '' : el.add(elm);
    return el;
}


export function output(elm = null) {
    let el = tag('output')
    elm == null ? '' : el.add(elm);
    return el;
}


export function p(elm = null) {
    let el = tag('p')
    elm == null ? '' : el.add(elm);
    return el;
}


export function param(elm = null) {
    let el = tag('param')
    elm == null ? '' : el.add(elm);
    return el;
}


export function picture(elm = null) {
    let el = tag('picture')
    elm == null ? '' : el.add(elm);
    return el;
}


export function pre(elm = null) {
    let el = tag('pre')
    elm == null ? '' : el.add(elm);
    return el;
}


export function progress(elm = null) {
    let el = tag('progress')
    elm == null ? '' : el.add(elm);
    return el;
}


export function q(elm = null) {
    let el = tag('q')
    elm == null ? '' : el.add(elm);
    return el;
}


export function rp(elm = null) {
    let el = tag('rp')
    elm == null ? '' : el.add(elm);
    return el;
}


export function rt(elm = null) {
    let el = tag('rt')
    elm == null ? '' : el.add(elm);
    return el;
}


export function ruby(elm = null) {
    let el = tag('ruby')
    elm == null ? '' : el.add(elm);
    return el;
}


export function s(elm = null) {
    let el = tag('s')
    elm == null ? '' : el.add(elm);
    return el;
}


export function samp(elm = null) {
    let el = tag('samp')
    elm == null ? '' : el.add(elm);
    return el;
}


export function scrit(elm = null) {
    let el = tag('scrit')
    elm == null ? '' : el.add(elm);
    return el;
}


export function section(elm = null) {
    let el = tag('section')
    elm == null ? '' : el.add(elm);
    return el;
}


export function select(elm = null) {
    let el = tag('select')
    elm == null ? '' : el.add(elm);
    return el;
}


export function small(elm = null) {
    let el = tag('small')
    elm == null ? '' : el.add(elm);
    return el;
}


export function source(elm = null) {
    let el = tag('source')
    elm == null ? '' : el.add(elm);
    return el;
}


export function span(elm = null) {
    let el = tag('span')
    elm == null ? '' : el.add(elm);
    return el;
}


export function strike(elm = null) {
    let el = tag('strike')
    elm == null ? '' : el.add(elm);
    return el;
}


export function strong(elm = null) {
    let el = tag('strong')
    elm == null ? '' : el.add(elm);
    return el;
}


export function style(elm = null) {
    let el = tag('style')
    elm == null ? '' : el.add(elm);
    return el;
}


export function sub(elm = null) {
    let el = tag('sub')
    elm == null ? '' : el.add(elm);
    return el;
}


export function summary(elm = null) {
    let el = tag('summary')
    elm == null ? '' : el.add(elm);
    return el;
}


export function sup(elm = null) {
    let el = tag('sup')
    elm == null ? '' : el.add(elm);
    return el;
}


export function svg(elm = null) {
    let el = tag('svg')
    elm == null ? '' : el.add(elm);
    return el;
}


export function table(elm = null) {
    let el = tag('table')
    elm == null ? '' : el.add(elm);
    return el;
}


export function tbody(elm = null) {
    let el = tag('tbody')
    elm == null ? '' : el.add(elm);
    return el;
}


export function td(elm = null) {
    let el = tag('td')
    elm == null ? '' : el.add(elm);
    return el;
}


export function template(elm = null) {
    let el = tag('template')
    elm == null ? '' : el.add(elm);
    return el;
}


export function textarea(elm = null) {
    let el = tag('textarea')
    elm == null ? '' : el.add(elm);
    return el;
}


export function tfoot(elm = null) {
    let el = tag('tfoot')
    elm == null ? '' : el.add(elm);
    return el;
}


export function th(elm = null) {
    let el = tag('th')
    elm == null ? '' : el.add(elm);
    return el;
}


export function thead(elm = null) {
    let el = tag('thead')
    elm == null ? '' : el.add(elm);
    return el;
}


export function time(elm = null) {
    let el = tag('time')
    elm == null ? '' : el.add(elm);
    return el;
}


export function title(elm = null) {
    let el = tag('title')
    elm == null ? '' : el.add(elm);
    return el;
}


export function tr(elm = null) {
    let el = tag('tr')
    elm == null ? '' : el.add(elm);
    return el;
}


export function track(elm = null) {
    let el = tag('track')
    elm == null ? '' : el.add(elm);
    return el;
}


export function tt(elm = null) {
    let el = tag('tt')
    elm == null ? '' : el.add(elm);
    return el;
}


export function u(elm = null) {
    let el = tag('u')
    elm == null ? '' : el.add(elm);
    return el;
}


export function ul(elm = null) {
    let el = tag('ul')
    elm == null ? '' : el.add(elm);
    return el;
}


export function video(elm = null) {
    let el = tag('video')
    elm == null ? '' : el.add(elm);
    return el;
}


export function wpr(elm = null) {
    let el = tag('wpr')
    elm == null ? '' : el.add(elm);
    return el;
}


