const Route = {};
Route.config={
    version:0.1,
    name:"Route",
    developer:"Md Atikul islam",
    date:'12/09/2023'
}
Route.path = ()=>{
    return location.pathname;
}
Route.url = ()=>{
    return location.href;
}
Route.post=(url,data=null,calback=null)=>{
    if(typeof(data)=="function"){
        $.ajax({
            method: "POST",
            url:url,
            success: function (e) {data(e)}
        });
    }else if(typeof(data)=="object"){
        $.ajax({
            method: "POST",
            url:url,
            data: data,
            success: function (e) {calback(e)}
        });
    }else{
        $.ajax({
            method: "POST",
            url:url,
            success: function (e) {calback(e)}
        });
    }
};
Route.click = (classname,data={},beforeback=null,calback)=>{
    data =data==null || data.isEmpty()?{}:data;
    $(classname).click(function(e){
        e.preventDefault()
        typeof (beforeback)=="function"?beforeback(e):"";
        const url     =$(this).attr("url");
        const element = $(this);
        const id      = $(this).attr("data");
        data.data=id;
        $.ajax({
            method: "POST",
            url:url,
            data: data,
            success: function (data) {calback(data,element)}
        });
    })
};
Route.submit = (fromid,beforeback=null,calback)=>{
    $(fromid).submit(function(e){
        e.preventDefault()
        typeof (beforeback)=="function"?beforeback(e):"";
        const fromData = new FormData(this);
        const url     = $(this).attr("action");
        const method  = $(this).attr("method");
        const from    = $(this);
        $.ajax({
            method: method,
            url:url,
            contentType:false,
            processData:false,
            data: fromData,
            success: function (data) {calback(data,from)}
        });
    })
}
Route.get = (url,data=null,beforeback=null,calback) =>{
    data   = typeof (data) == "object" ? data : {};
    typeof (beforeback)=="function"?beforeback():"";
    $.ajax({
        method: "GET",
        url:url,
        data: data,
        success: function (data) {calback(data)}
    });
}
Route.delete = (classname,beforeback=null,calback)=>{
    $(classname).click(function(){
        const url     = $(this).attr("url");
        const element = $(this);
        const id      = $(this).attr("id");
        typeof (beforeback)=="function"?beforeback(element):"";
        $.ajax({
            method: "POST",
            url:url,
            data:{id},
            success: function (data) {
                calback(data,element)
                if($(`#${id}_remove`)!=null){
                    $(`#${id}_remove`).fadeOut(200)
                    setTimeout(()=>{
                        $(`#${id}_remove`).remove();
                    },250)
                }
            }
        });
    })
}
Route.custom = (ob={})=>{
    $.ajax(ob);
}
Route.nav = (access=false,beforeback=null,calback=null)=>{
    //.route-link,#export,#root
    if(access){
        $(".route-link").click(function (e) {
            e.preventDefault()
            console.clear();
            const url   = $(this).attr("href");
            const title = $(this).attr("title");
            const element =$(this);
            Route.get(url, null, () => {
                window.history.pushState(null, null, url);
                typeof (beforeback)=="function"?beforeback(e):"";
                $(".route-link").removeClass("active")
            }, (e) => {
                $("#root").html(e);
                setTimeout(() => {
                    const html = $("#export").html();
                    $("#root").html(html);
                    Route.title(title);
                    typeof (calback)=="function"?calback(e):"";
                    (element).addClass("active")
                },0)
            })
        })        
    }
}
Route.title = (title="document")=>{
        document.title= title;
}
Route.search = (id,url,beforeback=null,calback=null)=>{
    $(id).keyup((e)=>{
        Route.get(url,{search:e.target.value},beforeback,calback);
    })
}
export default Route;
