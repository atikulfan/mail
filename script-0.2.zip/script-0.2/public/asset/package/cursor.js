const style =(x,y) =>{ 
    const size=30;
return `.cursor-contaienr {
    width: ${size}px;
    height: ${size}px;
    background: #36f25326;
    margin: auto;
    position: absolute;
    top: ${y-(size/2)}px;
    left: ${x-(size/2)}px;
    box-shadow: 0 0 5px #00000052;
    border-radius: 50%;
  }`
};
function cursor(x,y) {
    const cursorContiner = document.createElement("div");
    const StyleContainer = document.createElement("style");
    const beforcursor    =document.getElementById("65trbutye__wrftf1445222@@");
          StyleContainer.innerHTML=style(x,y);
          cursorContiner.classList.add("cursor-contaienr")
          cursorContiner.setAttribute("id","65trbutye__wrftf1445222@@")
          cursorContiner.append(StyleContainer);
          if(beforcursor==null){
            document.body.append(cursorContiner);
          }else{
            beforcursor.remove()
            document.body.append(cursorContiner);
          }
          setTimeout(()=>cursorContiner.remove(),60)

}
export default cursor;