function style(size=100) {
    return `
    .toas-container{
        height: auto;
        width: 150px;
        background: #0d0d0d;
        position: absolute;
        right: 10px;
        bottom: 10px;
        padding: 10px;
        box-shadow: 3px 2px 1px 2px #00000070;
    }
    .toast-title{
        padding: 0px;
        margin: 0px;
        font-size: 16px;
        color: #fff !important;
        text-transform: none !important;
    }
    .toast-timing {
        padding: 0;
        margin: 0;
        height: 4px;
        width: ${size}%;
        background: #ff0e52;
        position: absolute;
        left: 0;
        top: 0;
      }`
}
function toast(text="",time=10,calback=null) {
    let  count=100;
     const toastContaienr = document.createElement("div");
           toastContaienr.classList.add("toas-container");
     const toasttitle     = document.createElement("p");
           toasttitle.classList.add("toast-title")
           toasttitle.innerHTML=text;
           toastContaienr.append(toasttitle);
           document.body.append(toastContaienr)
    const  toasttiming = document.createElement("div");
           toasttiming.classList.add("toast-timing");
           toastContaienr.prepend(toasttiming);
    const  styles=document.createElement("style");
           toastContaienr.prepend(styles);
           styles.innerHTML =style();
   const timing= setInterval(()=>{
        count--;
        styles.innerHTML =style(count)
        if(count<0){
            clearInterval(timing)
            toastContaienr.remove()
            typeof(calback)=="function"?calback():"";
        }
    },time)

}
export default toast;