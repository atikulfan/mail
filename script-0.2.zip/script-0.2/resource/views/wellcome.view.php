
      <!DOCTYPE html>
      <html lang="en">
          <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <link rel="stylesheet" href="<?= ASSET("css/bootstrap.css") ?>">
              <link rel="shortcut icon" href="<?= URL("vendor/script/view/view.jpg") ?>" type="image/x-icon">
              <title>wellcome</title>
              <style>
                body {
                  background-color: #dd00c5;
                }
                .box {
                  height: 400px;
                  width: 400px;
                  overflow: hidden;
                  position: absolute;
                  left: 0;
                  right: 0;
                  bottom: 0;
                  top: 0;
                  margin: auto;
                  display: flex;
                  justify-content: center;
                  align-items: center;
                  flex-direction: column;
                }
                @keyframes anim_my {
                    0% {
                        rotate: 0deg;
                    }
                    100% {
                        rotate: 360deg;
                    }
                }
                .box img {
                    height: 50%;
                    width: 50%;
                    border-radius: 100%;
                    margin: auto;
                    display: block;
                    object-fit: cover;
                    animation-name: anim_my;
                    animation-duration: 5s;
                    animation-iteration-count: infinite;
                }
            </style>
          </head>
          <body>
            <main>
            <div class="box">
            <img src="<?= URL("vendor/script/view/view.jpg") ?>" />
            <?php use env\env; ?>
            <h4 class="text-light fw-bold">wellcome</h4>
          </div>
            </main>
            <!--||=====================================================||
                ||================JAVA SCRIPT LINK IN JS FILE =========|| 
                ||=====================================================||-->
                <script src="<?= ASSET("js/jquery.min.js") ?>"></script>
          </body>
      </html>