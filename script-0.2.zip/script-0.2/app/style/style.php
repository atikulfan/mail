<?php
namespace app;
function style()
{
    return [
        // classname , property
        'color_404'=>  "color:red;",
        'error'    =>  "height: 100%;
                        width: 100%;
                        position: absolute;
                        background: #e6dfdf;
                        box-sizing: border-box;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        font-size: 216%;
                        font-weight: bold;
                        letter-spacing: 1.1px;
                        text-transform: capitalize;
                    ",
        'wellocme' =>"  display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        font-size: 33px;
                        text-transform: capitalize;
                        color: blue;
                        font-weight: bold;
                        letter-spacing: 4px;
                    "
    ];
}
function css($css){ if(!empty($css)){return $css;}}
