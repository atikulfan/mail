<?php
use vendor\script\Auth;
class Middleware  
{
    static public function user(){
        
    }
}
