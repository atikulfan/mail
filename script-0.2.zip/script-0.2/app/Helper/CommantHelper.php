<?php
use vendor\script\Commant;

/*
||========================================================||
|| DONT REMOVE THIS CODE IT IS CODE FOR ANY COMMANT START ||
||========================================================||
*/
function CommantHelper($argv)
{
    //constant variable
    $varsion="0.2";
    $dlink  ="exemple.come?link=32423";
    $commant = new Commant();
    if (isset($argv[1]) and !empty($argv[1])) {
        $staus = strtolower($argv[1]);
        if ($staus == "make") {
            $type = isset($argv[2]) ? strtolower($argv[2]) : "";
            if (!$type == "") {
                if ($type == "controller") {
                    $name = isset($argv[3]) ? strtolower($argv[3]) : "";
                    if (!$name == "") {
                        $mode = isset($argv[3]) ? strtolower($argv[3]) : null;
                        echo $commant->controller($name, $mode);
                    } else {
                        echo "sorry not found $type name ...!!";
                    }
                }
                if ($type == "view") {
                    $name = isset($argv[3]) ? strtolower($argv[3]) : "";
                    if (!$name == "") {
                        echo $commant->view($name);
                    } else {
                        echo "sorry not found $type name ...!!";
                    }
                }
                if ($type == "mvc") {
                    $name = isset($argv[3]) ? strtolower($argv[3]) : "";
                    if (!$name == "") {
                        echo $commant->mvc($name);
                    } else {
                        echo "sorry not found $type name ...!!";
                    }
                }
                if ($type == "css") {
                    $name = isset($argv[3]) ? strtolower($argv[3]) : "";
                    if (!$name == "") {
                        echo $commant->css($name);
                    } else {
                        echo "sorry not found $type name ...!!";
                    }
                }
                if ($type == "js") {
                    $name = isset($argv[3]) ? strtolower($argv[3]) : "";
                    if (!$name == "") {
                        echo $commant->js($name);
                    } else {
                        echo "sorry not found $type name ...!!";
                    }
                }
            } else {
                echo "sorry not found $staus type .....!!";
            }
        } elseif ($staus == "serve") {
            echo "php -S localhost:8000 \n copy this code";
        } elseif ($staus == "tell") {
            $type = isset($argv[2]) ? strtolower($argv[2]) : "";
            if ($type == "version") {
                echo "||==========CONTACT DEVELOPER=============|| \n";
                echo "||                                        || \n";
                echo "||          Active version...$varsion v   || \n";
                echo "||                                        || \n";
                echo "||==========atikulcom19@gmail.com=========|| \n";
            } elseif ($type == "about") {
                echo "||========================================|| \n";
                echo "||==================ABOUT=================|| \n";
                echo "||Hi i am php script my runing version $varsion|| \n";
                echo "||i am all time update my varsion so any  || \n";
                echo "||time create a new project your.         || \n";
                echo "||you will download my new varsion file   || \n";
                echo "||download link :$dlink  || \n";
                echo "||========================================|| \n";
            }
        } elseif ($staus == "developer") {
            echo $commant->developer();
        } else {
            echo "sorry not found staus .....!!";
        }
    } else {
        echo "               ========= Commant============              \n";
        echo "||========================================================||\n";
        echo "||              TOTAL COMMATN INT SCRIPT                  ||\n";
        echo "||========================================================||\n";
        echo "||          1,php script tell version                     || \n";
        echo "||          2,php script tell about                       || \n";
        echo "||          3,php script make controller                  || \n";
        echo "||          4,php script make view                        || \n";
        echo "||          4,php script make mvc                         || \n";
        echo "||          4,php script make css                         || \n";
        echo "||          4,php script make js                          || \n";
        echo "||          4,php script developer                        || \n";
        echo "||========================================================||\n";
    }
}
/*
||========================================================||
|| DONT REMOVE THIS CODE IT IS CODE FOR ANY COMMANT END   ||
||========================================================||
*/