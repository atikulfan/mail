<?php
use vendor\script\Session;

const EXTANTION = 1;
const NAME = 0;
const HA = true;
const NA = false;
const YES = true;
const NO = false;
const ZERO = 0;
const ONE = 1;
const TWO = 2;
const THRRE = 3;
const FORE = 4;
const FIVE = 5;
const SIX = 6;
const ON = true;
const OFF = false;
const RESPONCE = 'responce';
function uniq_id()
{
    return substr(uniqid(), 7, 10) . rand(0, 10000000000);
}
function FILE_INFO(string $name, int $get)
{
    if (isset($name) == YES) {
        return explode(".", $name)[$get];
    }
}
function BR($value)
{
    if (isset($value) == YES) {
        echo "<pre>";
        print_r($value);
        echo "</pre>";
    }
}
function NOW()
{
    return date("d-m-Y", time());
}
function Setinfo($name, $messenge)
{
    if (isset($messenge) and isset($name)) {
        Session::set($name, $messenge);
    }
}
function Getinfo($name)
{
    if (isset($name)) {
        Session::get($name);
    }
}
function setTitle($title)
{
    if ($title != "") {
        Session::set("app_title", $title);
    }
}
function getTitle()
{
    return Session::get("app_title");
}
function setContent($name, $code)
{
    if (!empty($code) and $name != "") {
        Session::set($name, $code);
    }
}
function getContent($name)
{
    if ($name != "") {
        return Session::get($name);
    }
}
// validation healop
function mailCheck(string $text)
{
    if (str_contains($text, '@')) {
        $arry = explode('@', $text);
        return $arry[1] == "gmail.com" ? true : false;
    }
    return false;
}
function numberCheck(string $number){
    is_numeric($number)?true:false;
}
function array_to_json(array $arry){
    return json_encode($arry);
}
function json_to_Array($object){
    return json_decode($object);
}
function request_url(){
    return $_SERVER['REQUEST_URI'];
}

// ============CONTROLLER CREATE FUNCITONS ==================================
function layout(string $path){ // layout include
    if(empty($path)){
      echo "path is empty";
    }else {
      $path = trim($path,"/");
      $path = "resource/layout/$path.view.php";
      if (file_exists($path)) {
        return include_once($path);
      }else{
       echo "not found $path page";
      }
    }
    
  }
function inc(string $path){ // inc view include
    if(empty($path)){
      echo "path is empty";
    }else {
      $path = trim($path,"/");
      $path = "resource/inc/$path.view.php";
      if (file_exists($path)) {
        return include_once($path);
      }else{
       echo "not found $path page";
      }
    }
    
  }
function import_start(){echo '<div id="root">';}
function import_end(){echo '</div>';}
function export_start(){echo '<section id="export">';}
function export_end(){echo '</section>';}
