<?php
use vendor\script\Auth;
use vendor\script\DB;
use vendor\script\Redirect;
use vendor\script\Route;
use vendor\script\Session;
use vendor\script\Sql;
use vendor\script\Table;
use vendor\script\Upload;
use function vendor\script\fetch;
use function vendor\script\view;
class BaseController{
    public $success = ["error" => "", "responce" => ""];
    public function Auth(){return new Auth();}
    public function success($responce){
        $this->success['error']="0";
        $this->success['responce']=$responce;
    }
    public function error($responce){
        $this->success['error']="1";
        $this->success['responce']=$responce;
    }
    public function DB(){return new DB();}
    public function Redirect(){return new Redirect();}
    public function Route(){return new Route();}
    public function Session(){return new Session();}
    public function Sql(){return new Sql();}
    public function Table(string $name){return new Table($name);}
    public function Upload($fileName,$setLocation,$setNames=null,$setSize=null,$setType=null){return new Upload($fileName,$setLocation,$setNames=null,$setSize=null,$setType=null);}
    public function fetch($data,$optin){return fetch($data,$optin);}
    public function view(string $view,$data=null){return view($view,$data);}

}