<?php 
function Orderby(array $array,$mode = 'asc'){
    $neaData = [];
    if($mode=='asc'){
        for ($i=0; $i < count($array); $i++) { 
          array_push($neaData,$array[$i]);
        }
    }
    if($mode=='desc'){
        for ($i=count($array)-1; $i >=0 ; $i--) { 
            array_push($neaData,$array[$i]);
         }
         
    }
    if($mode=="rand"){
        for ($i=0; $i < count($array); $i++) { 
            $rnad =  array_rand($array);
            array_push($neaData,$array[$rnad]);
        }
    }
    return $neaData;
}
function limit(array $array,int $limt){
    $neaData = [];
    for ($i=0; $i < $limt; $i++) { 
        $rnad =  array_rand($array);
        array_push($neaData,$array[$rnad]);
    }
    return $neaData;

}