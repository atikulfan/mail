<?php
use vendor\script\DB;
use vendor\script\Table;

function includeController()
{
    $db = new DB;
    $modelfilepath = "app/controller/Controller.php";
    $alldata = $db->Read("controller");
    if (!empty($alldata) and count($alldata) > 0) {
        $fileRequest = "<?php ";
        foreach ($alldata as $datas) {
            $document = $datas->document;
            $fileRequest .= $document;
        }
        if ($fileRequest !== "") {
            $modelFileEdete = fopen($modelfilepath, 'w');
            fwrite($modelFileEdete, $fileRequest);
            fclose($modelFileEdete);
        }
    }
}
function setDbController(string $ControllerName)
{
    $offlineDatabase = new DB();
    $name = "$ControllerName" . "Controller.php";
    $document = "require_once '" . $name . "';";
    $alldata = $offlineDatabase->Read('controller');
    if (!empty($alldata) and count($alldata) > 0) {
        for ($i = 0; $i < count($alldata); $i++) {
            $filename = $alldata[$i]->document;
            if ($filename !== $document) {
                if ($i == 0) {
                    $offlineDatabase->Insert("controller", ['id' => ID(), 'document' => $document]);
                }
            }
        }
    } else {
        $offlineDatabase->Insert("controller", ['id' => ID(), 'document' => $document]);
    }
}
function ControllerCreate(string $name, string $mode = "b")
{
    $baseName = $name;
    $curd = ['TableCreate', 'Index', 'Select', 'Create', 'Update', 'Delete'];
    $basic = ['Index'];
    $funcitons = $mode == "b" ? $basic : $curd;
    $name = $name . "Controller";
    $path = "app/controller/$name.php";
    $constactur = '
        function __construct(){
          $this->' . $baseName . '= $this->Table($this->tablenames);
        }
      ';
    $deleteCode = '
    $id = Recive("id");
    if (!empty($id)) {
      if ($this->'. $baseName.'->getData($id)->num_rows > 0) {
        $this->'.$baseName.'->deleteData($id);
      } else {
        e_("data not found");
      }
    } else {
      e_("id not found");
    }';
    $createCode = '
    $data = $this->'.$baseName.'->get();
    $data->colum = "value";
    $this->'.$baseName.'->setData($data);';

    $updateCoder = '
    $id = Recive("id");
    if (!empty($id)) {
      if ($this->'.$baseName.'->getData($id)->num_rows > 0) {
       $data = $this->'.$baseName.'->get($id);
       $data->colum = "value";
       $this->'.$baseName.'->updateData($data);
      } else {
        e_("data not found");
      }
    } else {
      e_("id not found");
    } ';

    $globals = 'private $column =["id" => "int(255) PRIMARY KEY AUTO_INCREMENT","userId" => "varchar(15)"];';
    $globals2 = ' private $tablenames = "' . $baseName . '";';
    $tablevar = "private $" . "$baseName;";
    $funcitonsCode = null;
    for ($i = 0; $i < count($funcitons); $i++) {
        $funcName = $funcitons[$i];
        $newCoder =  $funcName=="TableCreate"?'$this->'.$baseName.'->create($this->column);':"";
        $funcitonsInsert1 =  $funcName=="Index"?'return $this->view($this->tablenames);':"";
        $funcitonsInsert2 =  $funcName=="Select"?'return $this->'.$baseName.'->getData();':"";
        $deletefunction   =  $funcName=="Delete"?$deleteCode:"";
        $createCodes      =  $funcName=="Create"?$createCode:"";
        $updateCods      =  $funcName=="Update"?$updateCoder:"";

        $funcitonsCode .= "public function $funcName(){
           $newCoder
           $funcitonsInsert1
           $funcitonsInsert2
           $deletefunction
           $createCodes
           $updateCods
        }";
    }
    $code = "<?php
      class $name extends BaseController{
          $globals
          $globals2
          $tablevar
          $constactur
          $funcitonsCode
      }";
    if (!file_exists($path)) {
        $NewController = fopen($path, "w");
        fwrite($NewController, $code);
        fclose($NewController);
        setDbController($baseName);
        includeController();
    }
}
function ViewCreate(string $name)
{
    $code = '
      <!DOCTYPE html>
      <html lang="en">
          <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <link rel="stylesheet" href="<?= ASSET("css/bootstrap.css") ?>">
              <link rel="stylesheet" href="<?= ASSET("css/'.$name.'.css") ?>">
              <link rel="shortcut icon" href="<?= URL("vendor/script/view/view.jpg") ?>" type="image/x-icon">
              <title>'.$name.'</title>
              <style>
                body {
                  background-color: #dd00c5;
                }
                .box {
                  height: 400px;
                  width: 400px;
                  overflow: hidden;
                  position: absolute;
                  left: 0;
                  right: 0;
                  bottom: 0;
                  top: 0;
                  margin: auto;
                  display: flex;
                  justify-content: center;
                  align-items: center;
                  flex-direction: column;
                }
                @keyframes anim_my {
                    0% {
                        rotate: 0deg;
                    }
                    100% {
                        rotate: 360deg;
                    }
                }
                .box img {
                    height: 50%;
                    width: 50%;
                    border-radius: 100%;
                    margin: auto;
                    display: block;
                    object-fit: cover;
                    animation-name: anim_my;
                    animation-duration: 5s;
                    animation-iteration-count: infinite;
                }
            </style>
          </head>
          <body>
            <main>
            <div class="box">
            <img src="<?= URL("vendor/script/view/view.jpg") ?>" />
            <?php use env\env; ?>
            <h4 class="text-light fw-bold">
              <?= env::APP_INFO()["App_names"] ?>
            </h4>
          </div>
            </main>
            <!--||=====================================================||
                ||================JAVA SCRIPT LINK IN JS FILE =========|| 
                ||=====================================================||-->
                <script src="<?= ASSET("js/jquery.min.js") ?>"></script>
                <script type="module" src="<?= ASSET("js/'.$name.'Handeler.js") ?>"></script>
          </body>
      </html>';
    $path = "resource/views/$name.view.php";
    if (!file_exists($path)) {
        $viewCreate = fopen($path, 'w');
        fwrite($viewCreate, $code);
        fclose($viewCreate);
    }
}
function MVC(string $name, string $tablenames = null, array $colum = null)
{
    ControllerCreate($name, 'c');
    ViewCreate($name);
    if (!$tablenames == null) {
        $Table = new Table($tablenames);
        $Table->create($colum);
    }
}