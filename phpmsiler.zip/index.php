<?php
include "mail/send.php";
if($_SERVER['REQUEST_METHOD']=="GET"){
    if(isset($_GET['subject']) and isset($_GET['to']) and isset($_GET['body'])){
        $subject    = $_GET['subject'];
        $body       = $_GET['body'];
        $to         = $_GET['to'];
        echo json_encode(send($subject,$to,$body,''));
    }
}
// ht?z5+3tFN7j