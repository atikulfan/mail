<?php
const COMPANYNAME   = "Softology bd tech";
const USERNAME      = "softologybdtech@gmail.com";
const USERPASSWORD  = 'fptgdgwqrfmqaqcs';                //'lsiepjapagfsgihh';
const HOST          = 'smtp.gmail.com';
const PORT          = 587;
