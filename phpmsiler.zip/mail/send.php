<?php

require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';
require 'connection.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

function send($subject, $email, $body,$for)
{
   try {
    $information=['error'=>0,'success'=>""];
    $mail = new PHPMailer();
    $mail->IsSMTP();
    // $mail->SMTPDebug = 2; 
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = "tls";
    $mail->Host = HOST;
    $mail->Port = PORT;
    $mail->Username =USERNAME;
    $mail->Password =USERPASSWORD;
    $mail->SetFrom($email,$for);
    $mail->FromName =COMPANYNAME;
    $mail->AddAddress($email);
    $mail->Subject = $subject;
    $mail->Body = $body;
    $mail->IsHTML (true);
    if ($mail->send()) {
      $information['success']=true;
    } else {
        $information['error']=1;
        $information['success']=$mail->ErrorInfo;
    }
    $mail->smtpClose();
   } catch (\Throwable $th) {
      $information['error']=1;
      $information['success']=$th;
   }

    return $information;
}
